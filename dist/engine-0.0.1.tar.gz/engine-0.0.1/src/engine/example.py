def hello_world():
    return "Amoeba, Friend"
